def exportar_txt(estatisticas, caminho):
    """Exporta as estatísticas para um arquivo TXT."""

    with open(caminho, "w", encoding="utf-8") as arquivo:

        arquivo.write("RELATÓRIO PDAD 2024\n")
        arquivo.write("\n")

        arquivo.write(
            f"Total de moradores: {estatisticas['total']}\n"
        )

        arquivo.write(
            f"Idade média: {estatisticas['idade_media']}\n"
        )

        arquivo.write(
            f"Escolaridade mais comum: "
            f"{estatisticas['escolaridade_mais_comum']}\n"
        )

        arquivo.write(
            f"Percentual com superior completo: "
            f"{estatisticas['percentual_superior']}%\n"
        )