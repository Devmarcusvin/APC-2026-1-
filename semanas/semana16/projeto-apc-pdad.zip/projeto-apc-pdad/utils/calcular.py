def filtrar_ra(df, ra):
    """Filtra os moradores por Região Administrativa."""

    return df[df["localidade"] == ra]


def distribuicao_escolaridade(df):
    """Calcula a quantidade de pessoas por escolaridade."""

    return df["escolaridade"].value_counts().sort_index()


def traduzir_escolaridade():
    """Retorna os nomes dos níveis de escolaridade."""

    return {
        1: "Sem instrução",
        2: "Fundamental incompleto",
        3: "Fundamental completo",
        4: "Médio incompleto",
        5: "Médio completo",
        6: "Superior incompleto",
        7: "Superior completo"
    }


def filtrar_faixa_etaria(df, faixa):
    """Filtra os moradores por faixa etária."""

    if faixa == "18-30":
        return df[
            (df["idade_calculada"] >= 18)
            & (df["idade_calculada"] <= 30)
        ]

    elif faixa == "31-45":
        return df[
            (df["idade_calculada"] >= 31)
            & (df["idade_calculada"] <= 45)
        ]

    elif faixa == "46-60":
        return df[
            (df["idade_calculada"] >= 46)
            & (df["idade_calculada"] <= 60)
        ]

    elif faixa == "60+":
        return df[df["idade_calculada"] > 60]

    return df


def calcular_estatisticas(df):
    """Calcula estatísticas do recorte selecionado."""

    total = int(len(df))

    idade_media = round(
        float(df["idade_calculada"].mean()),
        1
    )

    codigo = int(
        df["escolaridade"]
        .value_counts()
        .idxmax()
    )

    quantidade_escolaridade = int(
        df["escolaridade"]
        .value_counts()
        .max()
    )

    percentual_escolaridade = round(
        (quantidade_escolaridade / total) * 100,
        2
    )

    escolaridade_mais_comum = traduzir_escolaridade()[codigo]

    percentual_superior = round(
        float((df["escolaridade"] == 7).mean() * 100),
        2
    )

    return {
        "total": total,
        "idade_media": idade_media,
        "escolaridade_mais_comum": escolaridade_mais_comum,
        "percentual_escolaridade": percentual_escolaridade,
        "percentual_superior": percentual_superior
    }

        





def distribuicao_legivel(df):
    """Retorna a distribuição de escolaridade com nomes."""

    distribuicao = distribuicao_escolaridade(df)

    nomes = traduzir_escolaridade()

    resultado = {}

    for codigo, quantidade in distribuicao.items():
        resultado[nomes[codigo]] = quantidade

    return resultado


def traduzir_ra():
    """Retorna os nomes das Regiões Administrativas."""

    return {
        5301: "Plano Piloto",
        5302: "Gama",
        5303: "Taguatinga",
        5304: "Brazlândia",
        5305: "Sobradinho",
        5306: "Planaltina",
        5307: "Paranoá",
        5308: "Núcleo Bandeirante",
        5309: "Ceilândia",
        5310: "Guará",
        5311: "Cruzeiro",
        5312: "Samambaia",
        5313: "Santa Maria",
        5314: "São Sebastião",
        5315: "Recanto das Emas",
        5316: "Lago Sul",
        5317: "Riacho Fundo",
        5318: "Lago Norte",
        5319: "Candangolândia",
        5320: "Águas Claras",
        5321: "Riacho Fundo II",
        5322: "Sudoeste e Octogonal",
        5323: "Varjão",
        5324: "Park Way",
        5325: "SCIA",
        5326: "Sobradinho II",
        5327: "Jardim Botânico",
        5328: "Itapoã",
        5329: "SIA",
        5330: "Vicente Pires",
        5331: "Fercal",
        5332: "Sol Nascente / Pôr do Sol",
        5333: "Arniqueira",
        5334: "Arapoanga",
        5335: "Água Quente",
        5336: "Área Rural"
    }
def filtrar_genero(df, genero):
    """Filtra os moradores por identidade de gênero."""

    if genero == "Cisgênero":
        return df[df["id_genero"] == 1]

    elif genero == "Transgênero":
        return df[df["id_genero"] == 2]

    elif genero == "Outro":
        return df[df["id_genero"] == 3]

    return df