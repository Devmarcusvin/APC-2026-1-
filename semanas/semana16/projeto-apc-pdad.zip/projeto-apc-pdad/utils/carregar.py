import pandas as pd


def carregar_moradores():
    """Lê e limpa os dados dos moradores."""

    df = pd.read_csv(
        "dados/moradores.csv",
        sep=";",
        low_memory=False
    )

    # Remove escolaridade sem classificação
    df = df[df["escolaridade"] != 8]

    return df