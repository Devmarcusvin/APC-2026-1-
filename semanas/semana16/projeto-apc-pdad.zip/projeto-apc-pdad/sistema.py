import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

from utils.carregar import carregar_moradores
from utils.exportar import exportar_txt
from utils.calcular import (
    traduzir_ra,
    calcular_estatisticas,
    filtrar_ra,
    filtrar_faixa_etaria,
    filtrar_genero,
    distribuicao_legivel
)


# Carrega os dados já tratados da PDAD
df = carregar_moradores()

# Dicionário que relaciona código da RA com o nome da região
ras = traduzir_ra()

# Criação da janela principal
janela = tk.Tk()

janela.title("EducaDF")
janela.geometry("900x700")
# Frame do cabeçalho
frame_topo = tk.Frame(janela)
frame_topo.pack(fill="x", pady=10)

# Frame central
frame_central = tk.Frame(janela)
frame_central.pack(fill="x", padx=10)

# Painel da esquerda
frame_filtros = tk.LabelFrame(
    frame_central,
    text="Filtros"
)
frame_filtros.pack(
    side="left",
    fill="y",
    padx=10
)

# Painel da direita
frame_estatisticas = tk.LabelFrame(
    frame_central,
    text="Estatísticas"
)
frame_estatisticas.pack(
    side="left",
    fill="x",
    expand=True,
    padx=10
)


# Área do gráfico
frame_grafico = tk.Frame(janela)
frame_grafico.pack(
    fill="both",
    expand=True,
    padx=10,
    pady=10
)


def exportar_relatorio():
    """Exporta as estatísticas para um arquivo TXT."""

    caminho = filedialog.asksaveasfilename(
        defaultextension=".txt",
        filetypes=[("Arquivo TXT", "*.txt")]
    )

    if caminho:

        estatisticas = {
            "total": lbl_total.cget("text").replace(
                "Total de moradores: ", ""
            ),
            "idade_media": lbl_idade.cget("text").replace(
                "Idade média: ", ""
            ).replace(" anos", ""),
            "escolaridade_mais_comum": lbl_escolaridade.cget("text").replace(
                "Escolaridade mais comum: ", ""
            ),
            "percentual_superior": lbl_superior.cget("text").replace(
                "Percentual com superior completo: ", ""
            ).replace("%", "")
        }

        exportar_txt(
            estatisticas,
            caminho
        )
        messagebox.showinfo(
            "Exportação concluída",
            "Relatório exportado com sucesso!"
        )
        


def atualizar_dados():
    """Atualiza as estatísticas conforme os filtros selecionados."""

    # Pega a RA escolhida pelo usuário
    nome_ra = combo_ra.get()

    codigo_ra = None

    # Descobre qual é o código da RA selecionada
    for codigo, nome in ras.items():
        if nome == nome_ra:
            codigo_ra = codigo
            break

    # Filtra os moradores da RA selecionada
    # Filtra os moradores da RA selecionada
    df_filtrado = filtrar_ra(df, codigo_ra)

    # Aplica também o filtro de faixa etária
    faixa = combo_faixa.get()

    df_filtrado = filtrar_faixa_etaria(
        df_filtrado,
        faixa
    )

    genero = combo_genero.get()

    df_filtrado = filtrar_genero(
        df_filtrado,
        genero
    )

    

    # Recalcula as estatísticas após os filtros
    estatisticas = calcular_estatisticas(df_filtrado)

    # Atualiza os valores exibidos na tela
    lbl_total.config(
        text=f"Total de moradores: {estatisticas['total']}"
    )

    lbl_idade.config(
        text=f"Idade média: {estatisticas['idade_media']} anos"
    )

    lbl_escolaridade.config(
        text=f"Escolaridade mais comum: {estatisticas['escolaridade_mais_comum']}"
    )

    lbl_superior.config(
        text=f"Percentual com superior completo: {estatisticas['percentual_superior']}%"
    )

    # Gera os dados do gráfico
    dados_grafico = distribuicao_legivel(df_filtrado)

    # Limpa o gráfico anterior
    eixo.clear()

    # Cria o gráfico de barras
    eixo.bar(
        list(dados_grafico.keys()),
        list(dados_grafico.values())
    )

    # Mostra exatamente qual recorte está sendo analisado
    eixo.set_title(
        f"Distribuição da Escolaridade - {nome_ra} ({faixa})"
    )

    eixo.set_xlabel("Escolaridade")
    eixo.set_ylabel("Quantidade de Moradores")

    # Rotaciona os rótulos para melhorar a leitura
    eixo.tick_params(
        axis="x",
        rotation=45
    )

    # Ajusta automaticamente os espaços do gráfico
    figura.tight_layout()

    # Atualiza o gráfico na tela
    canvas.draw()


# Cabeçalho do sistema



# Informações do autor do trabalho
nome = tk.Label(
    janela,
    text="Aluno: Marcus Vinicius Paz Vieira"
)

nome.pack(
    in_=frame_topo
)

matricula = tk.Label(
    janela,
    text="Matrícula: 232029087"
)

matricula.pack(
    in_=frame_topo
)

descricao = tk.Label(
    janela,
    text="Recorte A - Perfil Educacional por Região Administrativa"
)

descricao.pack(
    in_=frame_topo,
    pady=10
)




# Seleção da Região Administrativa
# Seleção da Região Administrativa
label_ra = tk.Label(
    frame_filtros,
    text="Região Administrativa:"
)
label_ra.pack(pady=(10, 5))

combo_ra = ttk.Combobox(
    frame_filtros,
    width=25
)

combo_ra["values"] = list(ras.values())
combo_ra.current(0)
combo_ra.pack(padx=10)

# Seleção da faixa etária
label_faixa = tk.Label(
    frame_filtros,
    text="Faixa Etária:"
)

label_faixa.pack(
    pady=(10, 5)
)

combo_faixa = ttk.Combobox(
    frame_filtros,
    width=25
)

combo_faixa["values"] = (
    "18-30",
    "31-45",
    "46-60",
    "60+"
)

combo_faixa.current(0)

combo_faixa.pack(
    padx=10
)
    # Seleção da identidade de gênero
label_genero = tk.Label(
    frame_filtros,
    text="Identidade de Gênero:"
)

label_genero.pack(
    pady=(10, 5)
)

combo_genero = ttk.Combobox(
    frame_filtros,
    width=25
)

combo_genero["values"] = (
    "Todos",
    "Cisgênero",
    "Transgênero",
    "Outro"
)

combo_genero.current(0)

combo_genero.pack(
    padx=10
)



# Quantidade total de moradores carregados
registros = tk.Label(
    frame_filtros,
    text=f"Moradores carregados: {len(df):,}".replace(",", ".")
)

registros.pack(
    pady=10,
    padx=10
)

# Área de estatísticas
# Área de estatísticas
titulo_estatisticas = tk.Label(
    frame_estatisticas,
    text="ESTATÍSTICAS",
    font=("Arial", 14, "bold")
)

titulo_estatisticas.pack(
    pady=(15, 10)
)

lbl_total = tk.Label(
    frame_estatisticas,
    text=""
)

lbl_total.pack(
    pady=5
)

lbl_idade = tk.Label(
    frame_estatisticas,
    text=""
)

lbl_idade.pack(
    pady=5
)

lbl_escolaridade = tk.Label(
    frame_estatisticas,
    text=""
)

lbl_escolaridade.pack(
    pady=5
)

lbl_superior = tk.Label(
    frame_estatisticas,
    text=""
)

lbl_superior.pack(
    pady=5
)


# Botões principais
botao_atualizar = tk.Button(
    frame_filtros,
    text="Atualizar Dados",
    command=atualizar_dados
)

botao_atualizar.pack(
    pady=10,
    padx=10,
    fill="x"
)

botao_exportar = tk.Button(
    frame_filtros,
    text="Exportar Relatório",
    command=exportar_relatorio
)

botao_exportar.pack(
    pady=5,
    padx=10,
    fill="x"
)

# Área reservada para o gráfico


frame_grafico.pack(
    pady=20,
    fill="both",
    expand=True
)

# Estrutura do gráfico
figura = Figure(
    figsize=(10, 5)
)

eixo = figura.add_subplot(111)

canvas = FigureCanvasTkAgg(
    figura,
    master=frame_grafico
)

canvas.get_tk_widget().pack()

# Exibe os resultados iniciais automaticamente
atualizar_dados()

# Mantém a janela aberta
janela.mainloop()